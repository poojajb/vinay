package com.flightapp.model;

public class ResponseTemplateVo {

	private Flight flight;
	private AirLine airline;
	public Flight getFlight() {
		return flight;
	}
	public void setFlight(Flight flight) {
		this.flight = flight;
	}
	public AirLine getAirline() {
		return airline;
	}
	public void setAirline(AirLine airline) {
		this.airline = airline;
	}
	@Override
	public String toString() {
		return "ResponseTemplateVo [flight=" + flight + ", airline=" + airline + "]";
	}
	
}
