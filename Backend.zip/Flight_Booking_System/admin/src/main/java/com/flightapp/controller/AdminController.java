package com.flightapp.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.DisabledException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.flightapp.exceptions.AirlineException;
import com.flightapp.exceptions.FlightException;
import com.flightapp.model.Admin;
import com.flightapp.model.AirLine;

import com.flightapp.model.Flight;
import com.flightapp.model.JwtResponse;
import com.flightapp.model.Passenger;
import com.flightapp.model.ResponseTemplateVo;

import com.flightapp.service.AirLineServiceBo;
import com.flightapp.service.FlightServiceBo;
import com.flightapp.service.JwtUserDetailsService;

import com.flightapp.util.JwtTokenUtil;

import io.swagger.annotations.Api;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;

@RestController
@CrossOrigin
@SecurityRequirement(name = "adminapi")
@RequestMapping("/admin")
public class AdminController {

	@Autowired
	FlightServiceBo flightservice;
	
	@Autowired
	AirLineServiceBo airlineservice;
	
	@Autowired
	private RestTemplate resttemplate;
	
	@Autowired
	private ResponseTemplateVo responsevo;
	

	@RequestMapping(value = "/flight", method = RequestMethod.POST)
	public Flight addFlight(@RequestHeader("Authorization") String authorization,@RequestBody Flight f) {
    	MultiValueMap<String, String> headers = new LinkedMultiValueMap<String, String>();
    	headers.add("Authorization", authorization);
    	headers.add("Content-Type", "application/json");
    	
		return flightservice.addFlight(f);
	}
	
	
	@GetMapping("/getflightbyid/{id}")
	public Flight findFlightById(@PathVariable String id) throws FlightException{
		return flightservice.getFlightById(id);
		
		
	}
    

    @PutMapping("/updateflightbyid/{id}")
	public Flight updateFlightById(@RequestHeader("Authorization") String authorization,@PathVariable String id, @RequestBody Flight f){
    	MultiValueMap<String, String> headers = new LinkedMultiValueMap<String, String>();
    	headers.add("Authorization", authorization);
    	headers.add("Content-Type", "application/json");

    	return flightservice.updateFlightById(id,f);
	}
    
	
    @GetMapping("/getallflights")
    public List<Flight> getAllFlights() throws FlightException{
    	return flightservice.getAllFlights();
    }
    

    @DeleteMapping("/deleteflightbyid/{id}")
    public void deleteFlightById(@RequestHeader("Authorization") String authorization,@PathVariable String id) {
    	MultiValueMap<String, String> headers = new LinkedMultiValueMap<String, String>();
    	headers.add("Authorization", authorization);
    	headers.add("Content-Type", "application/json");

    	 flightservice.deleteFlightById(id);
    }
	

    @RequestMapping(value = "/airline", method = RequestMethod.POST)
	public AirLine addAirline(@RequestHeader("Authorization") String authorization,@RequestBody AirLine a) {
    	MultiValueMap<String, String> headers = new LinkedMultiValueMap<String, String>();
    	headers.add("Authorization", authorization);
    	headers.add("Content-Type", "application/json");

    	return airlineservice.addAirline(a);
	} 

    @DeleteMapping(value = "/deleteairline/{id}")
	public void deleteAirline(@RequestHeader("Authorization") String authorization,@PathVariable String id) {
    	MultiValueMap<String, String> headers = new LinkedMultiValueMap<String, String>();
    	headers.add("Authorization", authorization);
    	headers.add("Content-Type", "application/json");

    	 airlineservice.deleteAirline(id);
	} 

    @PutMapping("/updateairlinebyid/{id}")
	public AirLine updateAirlineById(@RequestHeader("Authorization") String authorization,@PathVariable String id, @RequestBody AirLine a){
    	MultiValueMap<String, String> headers = new LinkedMultiValueMap<String, String>();
    	headers.add("Authorization", authorization);
    	headers.add("Content-Type", "application/json");

    	return airlineservice.updateAirlineById(id,a);
	}

    @GetMapping("/getflightbysourceanddestination/{source}/{destination}")
	public List<Flight> findFlightBySourceAndDestination(@PathVariable String source,@PathVariable String destination)throws FlightException{
		return flightservice.findFlightBySourceAndDestination(source,destination);
	}

    @GetMapping("/getflightbyarrivalanddeparture/{arrivaltime}/{departuretime}")
	public List<Flight> findFlightByArrivalAndDeparture(@PathVariable String arrivaltime,@PathVariable String departuretime) throws FlightException{
		return flightservice.findFlightByArrivalAndDeparture(arrivaltime,departuretime);
	}
    

    @GetMapping("/getairlinebyname/{id}")
	public AirLine findAirlineByName(@RequestHeader("Authorization") String authorization,@PathVariable String id) throws AirlineException{
    	MultiValueMap<String, String> headers = new LinkedMultiValueMap<String, String>();
    	headers.add("Authorization", authorization);
    	headers.add("Content-Type", "application/json");

    	return airlineservice.getAirLineById(id);		
	}
    

    @GetMapping("/getallairlines")
    public List<AirLine> findAllAirLines(@RequestHeader("Authorization") String authorization) throws AirlineException{
    	MultiValueMap<String, String> headers = new LinkedMultiValueMap<String, String>();
    	headers.add("Authorization", authorization);
    	headers.add("Content-Type", "application/json");

    	return airlineservice.getAllAirLines();
    }


    @GetMapping("/getallpassengers")
    public List<Passenger> getAllPassengers(@RequestHeader("Authorization") String authorization){
    	MultiValueMap<String, String> headers = new LinkedMultiValueMap<String, String>();
    	headers.add("Authorization", authorization);
    	headers.add("Content-Type", "application/json");
    	String url = "http://localhost:8002/user/getallpassengers";
    	HttpMethod method = HttpMethod.GET;
    	HttpEntity data = new HttpEntity<>(headers);
         ParameterizedTypeReference<List<Passenger>> type = new ParameterizedTypeReference<List<Passenger>>(){};
         ResponseEntity<List<Passenger>> response = resttemplate.exchange(url, method, data, type);         
    	return response.getBody();
    }
    

    @GetMapping("/getairlineswithflights/{id}")
    public ResponseTemplateVo getAirlinesWithFlights(@RequestHeader("Authorization") String authorization,@PathVariable String id) throws FlightException, AirlineException {
    	Flight f = flightservice.getFlightById(id);
       	AirLine a = airlineservice.getAirLineById(f.getaName());
       	return flightservice.getairlinewithflights(f,a);  
    }
     
}
