package com.flightapp.exceptions;

public class FlightException extends Exception{

	public FlightException() {
		// TODO Auto-generated constructor stub
	}
	
	public FlightException(String m) {
		super(m);
	}


}
