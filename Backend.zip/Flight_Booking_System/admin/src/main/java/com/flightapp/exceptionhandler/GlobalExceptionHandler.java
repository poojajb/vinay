package com.flightapp.exceptionhandler;

import java.time.LocalDateTime;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import org.springframework.web.bind.annotation.ExceptionHandler;

import org.springframework.web.bind.annotation.ControllerAdvice;

import com.flightapp.exceptions.FlightException;
import com.flightapp.exceptions.AirlineException;

class ErrorResponse{
	private String message;
	private LocalDateTime now;

	public ErrorResponse()
    {
        super();
    }
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}

	public ErrorResponse(String message, LocalDateTime now) {
		super();
		this.message = message;
		this.now = now;
	}
	@Override
	public String toString() {
		return "ErrorResponse [message=" + message + ", now=" + now + "]";
	}
	public LocalDateTime getNow() {
		return now;
	}
	public void setNow(LocalDateTime now) {
		this.now = now;
	}
	
}

@ControllerAdvice
public class GlobalExceptionHandler {

//	@ExceptionHandler(MovieNotFoundException.class)
//	public ResponseEntity<String> handle(MovieNotFoundException e) {
//		return new ResponseEntity<String>(e.getMessage(), HttpStatus.OK);
//	}
	
	@ExceptionHandler(FlightException.class)
	public ResponseEntity<ErrorResponse> handle(FlightException e) {
		return new ResponseEntity<ErrorResponse>(
			new ErrorResponse(
				e.getMessage(), 
				LocalDateTime.now()
				), 
			
				HttpStatus.OK
		);
	}	
	
	@ExceptionHandler(AirlineException.class)
	public ResponseEntity<ErrorResponse> handle(AirlineException e) {
		return new ResponseEntity<ErrorResponse>(
			new ErrorResponse(
				e.getMessage(), 
				LocalDateTime.now()
				), 
			
				HttpStatus.OK
		);
	}	

}
