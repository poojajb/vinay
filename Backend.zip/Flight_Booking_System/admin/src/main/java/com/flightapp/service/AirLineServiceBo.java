package com.flightapp.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.flightapp.exceptions.AirlineException;
import com.flightapp.exceptions.FlightException;
import com.flightapp.model.AirLine;
import com.flightapp.model.Flight;
import com.flightapp.repository.AirLineRepository;

@Service
public class AirLineServiceBo {

	@Autowired
	AirLineRepository airlinerepo;
	
	public AirLine addAirline(AirLine a) {
		// TODO Auto-generated method stub
		return airlinerepo.save(a);
	}

	public AirLine getAirLineById(String id) throws AirlineException{
		// TODO Auto-generated method stub
		Optional<AirLine> optional = airlinerepo.findById(id);
		if(optional.isPresent()) {
			return optional.get();
		} else {
			
			throw new AirlineException("Database does not have any airline with id: "+id);
		}
	}

	public List<AirLine> getAllAirLines() throws AirlineException{
		// TODO Auto-generated method stub
		List<AirLine> airlines = airlinerepo.findAll();
		if(airlines.size()>0)
		return airlines;
		else
			throw new AirlineException("Data not found for airlines");
	}

	public void deleteAirline(String id) {
		// TODO Auto-generated method stub
		 airlinerepo.deleteById(id);
	}

	public AirLine updateAirlineById(String id, AirLine a) {
		// TODO Auto-generated method stub
		AirLine airline = airlinerepo.getById(id);
		airline.setAirlineName(a.getAirlineName());
		airline.setAirlineContact(a.getAirlineContact());
		airline.setAirlineAddress(a.getAirlineAddress());
		return airlinerepo.save(airline);
	}

}
