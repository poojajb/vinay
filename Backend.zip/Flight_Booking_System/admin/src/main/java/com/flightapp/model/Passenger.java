package com.flightapp.model;

import javax.persistence.Column;

public class Passenger {
	
	private int p_id;
	private String p_name;
	private String gender;
	private String p_email;
	private String age;
	private long p_contact;
	private int seat_no;
	private String passport_no;
	private String meal;
	private int no_of_seats;
	public int getP_id() {
		return p_id;
	}
	public void setP_id(int p_id) {
		this.p_id = p_id;
	}
	public String getP_name() {
		return p_name;
	}
	public void setP_name(String p_name) {
		this.p_name = p_name;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getP_email() {
		return p_email;
	}
	public void setP_email(String p_email) {
		this.p_email = p_email;
	}
	public String getAge() {
		return age;
	}
	public void setAge(String age) {
		this.age = age;
	}
	public long getP_contact() {
		return p_contact;
	}
	public void setP_contact(long p_contact) {
		this.p_contact = p_contact;
	}
	public int getSeat_no() {
		return seat_no;
	}
	public void setSeat_no(int seat_no) {
		this.seat_no = seat_no;
	}
	public String getPassport_no() {
		return passport_no;
	}
	public void setPassport_no(String passport_no) {
		this.passport_no = passport_no;
	}
	public String getMeal() {
		return meal;
	}
	public void setMeal(String meal) {
		this.meal = meal;
	}
	public int getNo_of_seats() {
		return no_of_seats;
	}
	public void setNo_of_seats(int no_of_seats) {
		this.no_of_seats = no_of_seats;
	}
	@Override
	public String toString() {
		return "Passenger [p_id=" + p_id + ", p_name=" + p_name + ", gender=" + gender + ", p_email=" + p_email
				+ ", age=" + age + ", p_contact=" + p_contact + ", seat_no=" + seat_no + ", passport_no=" + passport_no
				+ ", meal=" + meal + ", no_of_seats=" + no_of_seats + "]";
	}
   
}
