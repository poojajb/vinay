package com.flightapp.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@JsonIgnoreProperties({"hibernateLazyInitializer"})
@Entity
public class AirLine implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@Id
	private String airlineName;
	@Column(nullable=false)
    private String airlineContact;
	@Column(nullable=false)
    private String airlineAddress;
	public String getAirlineName() {
		return airlineName;
	}
	public void setAirlineName(String airlineName) {
		this.airlineName = airlineName;
	}
	public String getAirlineContact() {
		return airlineContact;
	}
	public void setAirlineContact(String airlineContact) {
		this.airlineContact = airlineContact;
	}
	public String getAirlineAddress() {
		return airlineAddress;
	}
	public void setAirlineAddress(String airlineAddress) {
		this.airlineAddress = airlineAddress;
	}
	@Override
	public String toString() {
		return "AirLine [airlineName=" + airlineName + ", airlineContact=" + airlineContact + ", airlineAddress="
				+ airlineAddress + "]";
	}
	
	
}
