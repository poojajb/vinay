package com.flightapp.service;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.flightapp.model.Admin;
import com.flightapp.repository.AdminRepostiory;

@Service
public class JwtUserDetailsService implements UserDetailsService {

    // entity -> user
    // repo.findById
	@Autowired
	AdminRepostiory adminrepo;

	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		
		Admin a = adminrepo.getById(username);
		if (a.getAdmin_name().equals(username)) {

            Set<SimpleGrantedAuthority> authorities = new HashSet<>();
            authorities.add(new SimpleGrantedAuthority("ROLE_" + "ADMIN"));

			// return new User("admin", "{noop}hello@world",new ArrayList<>());
			// return new User("admin", "{bcrypt}$2a$10$Dwzu0xQK7eHkBMA67KjPpelsTuvajmYArw5ruHxWvSgboxmAjp9mu", new ArrayList<>());
			return new User("admin", "$2a$10$Dwzu0xQK7eHkBMA67KjPpelsTuvajmYArw5ruHxWvSgboxmAjp9mu", authorities);
		} else if (a.getAdmin_name().equals(username)) {

            Set<SimpleGrantedAuthority> authorities = new HashSet<>();
            authorities.add(new SimpleGrantedAuthority("ROLE_" + "USER"));

			return new User("user", "$2a$10$Dwzu0xQK7eHkBMA67KjPpelsTuvajmYArw5ruHxWvSgboxmAjp9mu", authorities);
		}
        
        else {
			throw new UsernameNotFoundException("User not found with username: " + username);
		}
	}
}