package com.flightapp.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Parameter;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.flightapp.util.SequenceIdGenerator;

@JsonIgnoreProperties({"hibernateLazyInitializer"})
@Entity
public class Admin implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@Id
	private String admin_name;
	@Column(nullable=false)
	private String admin_password;
	@Column(nullable=false)
	
	public String getAdmin_name() {
		return admin_name;
	}
	
	public void setAdmin_name(String admin_name) {
		this.admin_name = admin_name;
	}
	public String getAdmin_password() {
		return admin_password;
	}
	public void setAdmin_password(String admin_password) {
		this.admin_password = admin_password;
	}
	@Override
	public String toString() {
		return "Admin [ admin_name=" + admin_name + ", admin_password=" + admin_password
				+ "]";
	}
	
}
