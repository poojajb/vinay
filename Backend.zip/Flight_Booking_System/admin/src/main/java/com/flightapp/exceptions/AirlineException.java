package com.flightapp.exceptions;

public class AirlineException extends Exception{
	
	public AirlineException() {
		// TODO Auto-generated constructor stub
	}
	
	public AirlineException(String m) {
		super(m);
	}

}
