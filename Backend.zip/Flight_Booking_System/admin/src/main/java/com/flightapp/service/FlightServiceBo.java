package com.flightapp.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.flightapp.exceptions.FlightException;
import com.flightapp.model.AirLine;
import com.flightapp.model.Flight;
import com.flightapp.model.ResponseTemplateVo;
import com.flightapp.repository.FlightRepository;

@Service
public class FlightServiceBo {

	@Autowired
	FlightRepository flightrepo;
	
	@Autowired
	ResponseTemplateVo responsevo;
	
	public Flight addFlight(Flight f) {
		// TODO Auto-generated method stub
		return flightrepo.save(f);
	}

	public Flight getFlightById(String id) throws FlightException {
		// TODO Auto-generated method stub
		Optional<Flight> optional = flightrepo.findById(id);
		if(optional.isPresent()) {
			return optional.get();
		} else {
			
			throw new FlightException("Database does not have any flight with id: "+id);
		}
	}

	public Flight updateFlightById(String id, Flight f) {
		// TODO Auto-generated method stub
		Flight flight = flightrepo.getById(id);
		
		flight.setF_id(id);
		flight.setSource(f.getSource());
		flight.setDestination(f.getDestination());
		flight.setArrivalTime(f.getArrivalTime());
		flight.setDepartureTime(f.getDepartureTime());
		flight.setBusinessSeats(f.getBusinessSeats());
		flight.setEconomySeats(f.getEconomySeats());
		flight.setInstrumentsUsed(f.getInstrumentsUsed());
		flight.setMealType(f.getMealType());
		flight.setNoOfRows(f.getNoOfRows());
		flight.setScheduledDays(f.getScheduledDays());
	    flight.setaName(f.getaName());
	    flight.setTotalFare(f.getTotalFare());
	    return flightrepo.save(flight);
		
		
	
	}

	public List<Flight> getAllFlights() throws FlightException{
		// TODO Auto-generated method stub
		List<Flight> flights = flightrepo.findAll();
		if(flights.size()>0)
		return flights;
		else
			throw new FlightException("No Flights Found");
	}

	public void deleteFlightById(String id) {
		// TODO Auto-generated method stub
		flightrepo.deleteById(id);
		
	}

	public List<Flight> findFlightBySourceAndDestination(String s, String d)throws FlightException {
		// TODO Auto-generated method stub
		List<Flight> flights =flightrepo.findFlightBySourceAndDestination(s,d);
		if(flights.size()>0)
		return flights;
		else
		throw new FlightException("flights doesnot exist with following source and destination"+s+" "+d);
		
	}

	public ResponseTemplateVo getairlinewithflights(Flight f, AirLine a) {
		// TODO Auto-generated method stub
		responsevo.setFlight(f);
       	responsevo.setAirline(a);
		
		return responsevo;
	}

	public List<Flight> findFlightByArrivalAndDeparture(String arrivaltime, String departuretime) throws FlightException{
		// TODO Auto-generated method stub
		List<Flight> flights = flightrepo.findFlightByArrivalTimeAndDepartureTime(arrivaltime,departuretime);
		if(flights.size()>0)
		return flights;
		else
			throw new FlightException("flight doesnot exists with following arrival:"+arrivaltime+"departure:"+departuretime);
	}



}
