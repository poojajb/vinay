package com.flightapp.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.flightapp.model.Flight;

public interface FlightRepository extends JpaRepository<Flight, String>{

	public Flight save(Flight f);

	public List<Flight> findFlightBySourceAndDestination(String s, String d);

	public List<Flight> findFlightByArrivalTimeAndDepartureTime(String arrivaltime, String departuretime);


	

}
