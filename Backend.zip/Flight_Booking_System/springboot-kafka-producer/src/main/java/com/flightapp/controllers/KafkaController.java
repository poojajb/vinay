package com.flightapp.controllers;

import java.time.LocalDateTime;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.flightapp.model.Flight;


@RestController
@RequestMapping("/kafka")
public class KafkaController {
	
	@Autowired
    private KafkaTemplate<String, Flight> kafkaTemplate;
	
	@Autowired
	private RestTemplate resttemplate;

	
	private static final String TOPIC = "kafka_topic";

    @GetMapping("/Flightdetailsbyid/{id}")
    public String getPassengerDetails(@RequestHeader("Authorization") String authorization,@PathVariable String id) {
    	MultiValueMap<String, String> headers = new LinkedMultiValueMap<String, String>();
		headers.add("Authorization", authorization);
		headers.add("Content-Type", "application/json");
        String url = "http://localhost:8002/admin/getflightbyid/"+id;
    	HttpMethod method = HttpMethod.GET;
    	HttpEntity data = new HttpEntity<>(headers);
         ParameterizedTypeReference<Flight> type = new ParameterizedTypeReference<Flight>(){};
         ResponseEntity<Flight> response = resttemplate.exchange(url, method, data, type);         
    	Flight flight = response.getBody();
        kafkaTemplate.send(TOPIC, flight);

       return "flight exists with id"+flight.toString();
    }


}
