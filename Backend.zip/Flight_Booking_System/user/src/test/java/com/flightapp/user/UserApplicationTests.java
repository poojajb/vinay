
  package com.flightapp.user;
  
  import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test; 
  import org.springframework.boot.test.context.SpringBootTest;

import com.flightapp.exceptions.BookingException;
import com.flightapp.model.Booking;
import com.flightapp.service.BookingServiceBo;
  
  @SpringBootTest class UserApplicationTests {
  
	  
	  BookingServiceBo bookingService;
  @Test void contextLoads() { }
  
  @Test void bookingWithPnr() throws BookingException{
	  Booking booking = new Booking();
	  booking.setF_id("FLY_001");
	  booking.setP_id(2);
	  booking.setUserid(1);
	  bookingService.addBooking(booking);
	  Assertions.assertNotNull(bookingService.findBookingById("PNR_00000004"));
  }
  
  } 
  
 