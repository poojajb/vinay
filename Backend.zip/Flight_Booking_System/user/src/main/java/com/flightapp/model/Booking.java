package com.flightapp.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;

import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Parameter;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.flightapp.util.SequenceIdGenerator;

@JsonIgnoreProperties({"hibernateLazyInitializer"})
@Entity
public class Booking implements Serializable{

	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "PNR_SEQ")
	@GenericGenerator(
			name = "PNR_SEQ", 
			strategy = "com.flightapp.util.SequenceIdGenerator",
			parameters = {
					@Parameter(name = SequenceIdGenerator.INCREMENT_PARAM, value = "1"),
					@Parameter(name = SequenceIdGenerator.VALUE_PREFIX_PARAMETER, value = "PNR_"),
					@Parameter(name = SequenceIdGenerator.NUMBER_FORMAT_PARAMETER, value = "%08d")})
	private String pnr_number;
	
	@Column(nullable=false)
	private int userId;
	
	@Column(nullable=false)
	private int p_id;
	
	@Column(nullable=false)
	private String f_id;
	
	public String getPnr_number() {
		return pnr_number;
	}

	public void setPnr_number(String pnr_number) {
		this.pnr_number = pnr_number;
	}

	public int getUserId() {
		return userId;
	}

	public void setUserid(int userId) {
		this.userId = userId;
	}

	public int getP_id() {
		return p_id;
	}

	public void setP_id(int p_id) {
		this.p_id = p_id;
	}

	public String getF_id() {
		return f_id;
	}

	public void setF_id(String f_id) {
		this.f_id = f_id;
	}

	
	
	
}