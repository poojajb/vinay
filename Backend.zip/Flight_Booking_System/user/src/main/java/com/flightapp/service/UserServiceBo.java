package com.flightapp.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.flightapp.model.User;
import com.flightapp.repository.UserRepository;

@Service
public class UserServiceBo {
	
	@Autowired
	private UserRepository userrepo;

	public User addUser(User u) {
		// TODO Auto-generated method stub
		return userrepo.save(u);
	}

	public User findUserById(int id) {
		// TODO Auto-generated method stub
		return userrepo.getById(id);
	}

	public List<User> getAllUsers() {
		// TODO Auto-generated method stub
		return userrepo.findAll();
	}

	public User findByEmailId(String email_id) {
		// TODO Auto-generated method stub
		return userrepo.findByEmailId(email_id);
	}

	
	

}
