package com.flightapp.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.flightapp.model.User;


public interface UserRepository extends JpaRepository<User, Integer>{

	public User save(User u) ;

	public User findByEmailId(String email_id);

	

		

}
