package com.flightapp.model;

import javax.persistence.Column;

public class Flight {

	private String f_id;
	
	private String source;
	
	private String destination;
	
	private String arrivalTime;
	
	private String departureTime;
	
    private String scheduledDays;

    private String instrumentsUsed;
	
    private int businessSeats;
	
   private int economySeats;
	
    private int noOfRows;
	
    private String mealType;
	
	private String aName;

	private int totalFare;
	
	public String getF_id() {
		return f_id;
	}

	public void setF_id(String f_id) {
		this.f_id = f_id;
	}

	public String getSource() {
		return source;
	}

	public void setSource(String source) {
		this.source = source;
	}

	public String getDestination() {
		return destination;
	}

	public void setDestination(String destination) {
		this.destination = destination;
	}

	public String getArrivalTime() {
		return arrivalTime;
	}

	public void setArrivalTime(String arrivalTime) {
		this.arrivalTime = arrivalTime;
	}

	public String getDepartureTime() {
		return departureTime;
	}

	public void setDepartureTime(String departureTime) {
		this.departureTime = departureTime;
	}

	public String getScheduledDays() {
		return scheduledDays;
	}

	public void setScheduledDays(String scheduledDays) {
		this.scheduledDays = scheduledDays;
	}

	public String getInstrumentsUsed() {
		return instrumentsUsed;
	}

	public void setInstrumentsUsed(String instrumentsUsed) {
		this.instrumentsUsed = instrumentsUsed;
	}

	public int getBusinessSeats() {
		return businessSeats;
	}

	public void setBusinessSeats(int businessSeats) {
		this.businessSeats = businessSeats;
	}

	public int getEconomySeats() {
		return economySeats;
	}

	public void setEconomySeats(int economySeats) {
		this.economySeats = economySeats;
	}

	public int getNoOfRows() {
		return noOfRows;
	}

	public void setNoOfRows(int noOfRows) {
		this.noOfRows = noOfRows;
	}

	public String getMealType() {
		return mealType;
	}

	public void setMealType(String mealType) {
		this.mealType = mealType;
	}

	public String getaName() {
		return aName;
	}

	public void setaName(String aName) {
		this.aName = aName;
	}

	public int getTotalFare() {
		return totalFare;
	}

	public void setTotalFare(int totalFare) {
		this.totalFare = totalFare;
	}

	@Override
	public String toString() {
		return "Flight [f_id=" + f_id + ", source=" + source + ", destination=" + destination + ", arrivalTime="
				+ arrivalTime + ", departureTime=" + departureTime + ", scheduledDays=" + scheduledDays
				+ ", instrumentsUsed=" + instrumentsUsed + ", businessSeats=" + businessSeats + ", economySeats="
				+ economySeats + ", noOfRows=" + noOfRows + ", mealType=" + mealType + ", aName=" + aName
				+ ", totalFare=" + totalFare + "]";
	}

	
}
