package com.flightapp.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.flightapp.exceptions.BookingException;
import com.flightapp.exceptions.PassengerException;
import com.flightapp.model.Booking;
import com.flightapp.model.Flight;
import com.flightapp.model.Passenger;
import com.flightapp.model.ResponseTemplateVo;
import com.flightapp.model.User;
import com.flightapp.service.BookingServiceBo;
import com.flightapp.service.PassengerServiceBo;
import com.flightapp.service.UserServiceBo;

@RestController
@CrossOrigin(origins = "http://localhost:4200")
@RequestMapping("/user")
public class UserController {

	@Autowired
	private UserServiceBo userservice;

	@Autowired
	private PassengerServiceBo passengerservice;

	@Autowired
	private BookingServiceBo bookingservice;

	@Autowired
	private RestTemplate resttemplate;

	@Autowired
	private ResponseTemplateVo responsevo;

	

	@PostMapping("/")
	public User addUser(@RequestBody User u) {
		System.out.println("enter the controller");
		return userservice.addUser(u);
		
	}

	@GetMapping("/getbyid/{id}")
	public User findUserById(@PathVariable int id) {
		return userservice.findUserById(id);
	}

	
	  @GetMapping("/getuserbyemailid/{emailid}") 
	  public User getUserByEmailId(@PathVariable String emailid){ 
		  return userservice.findByEmailId(emailid); 
	  }
	 

	@GetMapping("/getallusers")
	public List<User> getAllUsers() {
		return userservice.getAllUsers();
	}

	@RequestMapping(value = "/passenger", method = RequestMethod.POST)
	public Passenger addPassenger(@RequestBody Passenger p) {
		return passengerservice.addPassenger(p);
	}

	@GetMapping("/getpassengerbyid/{id}")
	public Passenger findPassengerById(@PathVariable int id) throws PassengerException{
		
		
		return passengerservice.findPassengerById(id);
		
	}

	@PutMapping("/updatepassengerbyid/{id}")
	public Passenger updatePassengerById(@PathVariable int id, @RequestBody Passenger p) {
		return passengerservice.updatePassengerById(id, p);
	}

	@GetMapping("/getallpassengers")
	public List<Passenger> getAllPassengers() {
		return passengerservice.getAllPassengers();
	}

	@DeleteMapping("/deletepassengerbyid/{id}")
	public void deletePassengerById(@PathVariable int id) {
		passengerservice.deletePassengerById(id);
	}

	@RequestMapping(value = "/booking", method = RequestMethod.POST)
	public Booking addBooking(@RequestBody Booking b) {
		return bookingservice.addBooking(b);
	}

	@GetMapping("/getbookingbyid/{id}") 
	public Booking findBookingById(@PathVariable String id)throws BookingException {
		return bookingservice.findBookingById(id);
	}

	@DeleteMapping("/deletebookingbyid/{id}")
	public void deleteBookingById(@PathVariable String id) {
		 bookingservice.deleteBookingById(id);
	}
	
	@GetMapping("/getallbookings")
	public List<Booking> getAllBookings() throws BookingException{
		return bookingservice.getAllBookings();
	}

	@GetMapping("/getallbookingsbyemailid/{emailid}")
	public List<Booking> getAllBookingsByEmailId(@PathVariable String emailid) throws BookingException{
        User user = userservice.findByEmailId(emailid);
        List<Booking> bookings = bookingservice.findByUser_Id(user.getUserId());
        
		return bookings;
        
	}

	@GetMapping("/getallflights")
	public List<Flight> getAllFlights() {
		String url = "http://localhost:8002/admin/getallflights";
		HttpMethod method = HttpMethod.GET;
		HttpEntity data = null;
		ParameterizedTypeReference<List<Flight>> type = new ParameterizedTypeReference<List<Flight>>() {
		};
		ResponseEntity<List<Flight>> response = resttemplate.exchange(url, method, data, type);

		return response.getBody();
	}

	@GetMapping("/getallflightsbysourceanddestination/{source}/{destination}")
	public List<Flight> getAllFlightsBySourceandDestination(@PathVariable String source, @PathVariable String destination) {
		String url = "http://localhost:8002/admin/getflightbysourceanddestination/" + source + "/" + destination + "";
		HttpMethod method = HttpMethod.GET;
		HttpEntity data = null;
		ParameterizedTypeReference<List<Flight>> type = new ParameterizedTypeReference<List<Flight>>() {
		};
		ResponseEntity<List<Flight>> response = resttemplate.exchange(url, method, data, type);

		return response.getBody();
	}

	@GetMapping("/getallflightsbyarrivalanddeparture/{arrivaltime}/{departuretime}")
	public List<Flight> getAllFlightsByArrivalandDeparture(
			@PathVariable String arrivaltime, @PathVariable String departuretime) {
			String url = "http://localhost:8002/admin/getflightbyarrivalanddeparture/" + arrivaltime + "/" + departuretime + "";
		HttpMethod method = HttpMethod.GET;
		HttpEntity data = null;
		ParameterizedTypeReference<List<Flight>> type = new ParameterizedTypeReference<List<Flight>>() {
		};
		ResponseEntity<List<Flight>> response = resttemplate.exchange(url, method, data, type);

		return response.getBody();
	}

	@GetMapping("/bookingdetailsbyid/{id}")
	public ResponseTemplateVo getBookingWithAllDetails(@RequestHeader("Authorization") String authorization,
			@PathVariable String id) throws BookingException, PassengerException {

		Booking booking = bookingservice.findBookingById(id);

		User user = userservice.findUserById(booking.getUserId());

		Passenger passenger = passengerservice.findPassengerById(booking.getP_id());

		MultiValueMap<String, String> headers = new LinkedMultiValueMap<String, String>();
		headers.add("Authorization", authorization);
		headers.add("Content-Type", "application/json");
		String url = "http://localhost:8002/admin/getflightbyid/" + booking.getF_id() + "";
		HttpMethod method = HttpMethod.GET;
		HttpEntity data = new HttpEntity<>(headers);
		ParameterizedTypeReference<Flight> type = new ParameterizedTypeReference<Flight>() {
		};
		ResponseEntity<Flight> response = resttemplate.exchange(url, method, data, type);

		Flight flight = response.getBody();

		return bookingservice.getBookingDetails(user, booking, flight, passenger);

	}

}