package com.flightapp.exceptions;

public class BookingException extends Exception{
	
	public BookingException()
	{
		
	}

	public BookingException(String m)
	{
		super(m);
	}
}
