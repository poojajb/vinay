package com.flightapp.service;

import java.util.Collection;
import java.util.List;
import java.util.Optional;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.flightapp.exceptions.BookingException;
import com.flightapp.model.Booking;
import com.flightapp.model.Flight;
import com.flightapp.model.Passenger;
import com.flightapp.model.ResponseTemplateVo;
import com.flightapp.model.User;
import com.flightapp.repository.BookingRepository;

@Service
public class BookingServiceBo {

	@Autowired
	BookingRepository bookingrepo;
	
	@Autowired
	private ResponseTemplateVo responsevo;
	
	
	public Booking addBooking(Booking b) {
		// TODO Auto-generated method stub
		return bookingrepo.save(b);
	}



	public List<Booking> getAllBookings() throws BookingException {
		// TODO Auto-generated method stub
		List<Booking> bookings =bookingrepo.findAll();
		if(bookings.size()>0)
		return bookings;
		else
			throw new BookingException("No Bookings Found");
	}

	public void deleteBookingById(String id) {
		// TODO Auto-generated method stub
		bookingrepo.deleteById(id);
	}



	public Booking findBookingById(String id) throws BookingException{
		
		Optional<Booking> optional = bookingrepo.findById(id);
		
		if(optional.isPresent())
		return optional.get();
		else
			throw new BookingException("data not found with booking id"+id);
	}



	public ResponseTemplateVo getBookingDetails(User user, Booking booking, Flight flight, Passenger passenger) {
		// TODO Auto-generated method stub
		  responsevo.setUser(user);
	        responsevo.setBooking(booking);
	        responsevo.setFlight(flight);
	        responsevo.setPassenger(passenger);
		return responsevo;
	}



	public List<Booking> findByUser_Id(int user_id) throws BookingException {
		// TODO Auto-generated method stub
		List<Booking> bookings = bookingrepo.findByUserId(user_id);
		if(bookings.size()>0)
		return bookings;
		else
			throw new BookingException("No Booking History found");
	}










	
}
