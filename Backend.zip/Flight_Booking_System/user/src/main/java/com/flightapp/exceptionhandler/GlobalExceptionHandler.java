package com.flightapp.exceptionhandler;

import java.time.LocalDateTime;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import org.springframework.web.bind.annotation.ExceptionHandler;

import com.flightapp.exceptions.BookingException;
import com.flightapp.exceptions.PassengerException;

import org.springframework.web.bind.annotation.ControllerAdvice;


class ErrorResponse{
	private String message;
	private LocalDateTime now;

	public ErrorResponse()
    {
        super();
    }
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}

	public ErrorResponse(String message, LocalDateTime now) {
		super();
		this.message = message;
		this.now = now;
	}
	@Override
	public String toString() {
		return "ErrorResponse [message=" + message + ", now=" + now + "]";
	}
	public LocalDateTime getNow() {
		return now;
	}
	public void setNow(LocalDateTime now) {
		this.now = now;
	}
	
}

@ControllerAdvice
public class GlobalExceptionHandler {

	
	@ExceptionHandler(BookingException.class)
	public ResponseEntity<ErrorResponse> handle(BookingException e) {
		return new ResponseEntity<ErrorResponse>(
			new ErrorResponse(
				e.getMessage(), 
				LocalDateTime.now()
				), 
			
				HttpStatus.OK
		);
	}
	
	@ExceptionHandler(PassengerException.class)
	public ResponseEntity<ErrorResponse> handle(PassengerException e) {
		return new ResponseEntity<ErrorResponse>(
			new ErrorResponse(
				e.getMessage(), 
				LocalDateTime.now()
				), 
			
				HttpStatus.OK
		);
	}

}
