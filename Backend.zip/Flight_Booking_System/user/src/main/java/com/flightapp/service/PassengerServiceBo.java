package com.flightapp.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;

import com.flightapp.exceptions.PassengerException;
import com.flightapp.model.Booking;
import com.flightapp.model.Passenger;
import com.flightapp.model.User;
import com.flightapp.repository.PassengerRepository;

@Service
public class PassengerServiceBo {
	
	@Autowired
	PassengerRepository passengerrepo;

	public Passenger addPassenger(Passenger p) {
		// TODO Auto-generated method stub
		return passengerrepo.save(p);
	}

	@Cacheable(key="#id", value="passenger-store")
	public Passenger findPassengerById(int id) throws PassengerException {
		
		// TODO Auto-generated method stub
		Optional<Passenger> optional = passengerrepo.findById(id);
		if(optional.isPresent())
		return optional.get();
		else
			throw new PassengerException("Passenger Doesnot exists with id:"+id);
		
	}

	public List<Passenger> getAllPassengers() {
		// TODO Auto-generated method stub
		return passengerrepo.findAll();
	}

	public void deletePassengerById(int id) {
		// TODO Auto-generated method stub
		 passengerrepo.deleteById(id);
		 
	}

	public Passenger updatePassengerById(int id, Passenger p) {
		// TODO Auto-generated method stub
		Passenger pass = passengerrepo.getById(id);
		pass.setP_name(p.getP_name());
		pass.setAge(p.getAge());
		pass.setGender(p.getGender());
		pass.setMeal(p.getMeal());
		pass.setNo_of_seats(p.getNo_of_seats());
		pass.setP_contact(p.getP_contact());
		pass.setPassport_no(p.getPassport_no());
		pass.setP_email(p.getP_email());
		pass.setSeat_no(p.getSeat_no());
		
		return passengerrepo.save(pass);
	}


}
