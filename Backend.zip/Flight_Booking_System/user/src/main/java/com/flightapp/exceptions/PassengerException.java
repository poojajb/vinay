package com.flightapp.exceptions;

public class PassengerException extends Exception{
	
	public PassengerException()
	{
		
	}

	public PassengerException(String m)
	{
		super(m);
	}

}
