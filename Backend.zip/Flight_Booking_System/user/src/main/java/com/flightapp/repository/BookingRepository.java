package com.flightapp.repository;

import java.util.Collection;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.flightapp.model.Booking;
import com.flightapp.model.Passenger;

public interface BookingRepository extends JpaRepository<Booking, String>{

	public Booking save(Booking b);

	public List<Booking> findByUserId(int user_id);




}
