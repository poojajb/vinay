package com.flightapp.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Parameter;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.flightapp.util.SequenceIdGenerator;

@JsonIgnoreProperties({"hibernateLazyInitializer"})
@Entity
public class Passenger implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int p_id;
	@Column(nullable=false)
	private String p_name;
	@Column(nullable=false)
	private String gender;
	@Column(nullable=false)
	private String p_email;
	@Column(nullable=false)
	private String age;
	@Column(nullable=false)
	private long p_contact;
	@Column(nullable=false)
	private int seat_no;
	private String passport_no;
	@Column(nullable=false)
	private String meal;
	@Column(nullable=false)
	private int no_of_seats;
	
	public int getP_id() {
		return p_id;
	}
	public void setP_id(int p_id) {
		this.p_id = p_id;
	}
	public String getP_name() {
		return p_name;
	}
	public void setP_name(String p_name) {
		this.p_name = p_name;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getP_email() {
		return p_email;
	}
	public void setP_email(String p_email) {
		this.p_email = p_email;
	}
	public String getAge() {
		return age;
	}
	public void setAge(String age) {
		this.age = age;
	}
	public long getP_contact() {
		return p_contact;
	}
	public void setP_contact(long p_contact) {
		this.p_contact = p_contact;
	}
	public int getSeat_no() {
		return seat_no;
	}
	public void setSeat_no(int seat_no) {
		this.seat_no = seat_no;
	}
	public String getPassport_no() {
		return passport_no;
	}
	public void setPassport_no(String passport_no) {
		this.passport_no = passport_no;
	}
	public String getMeal() {
		return meal;
	}
	public void setMeal(String meal) {
		this.meal = meal;
	}
	public int getNo_of_seats() {
		return no_of_seats;
	}
	public void setNo_of_seats(int no_of_seats) {
		this.no_of_seats = no_of_seats;
	}
	@Override
	public String toString() {
		return "Passenger [p_id=" + p_id + ", p_name=" + p_name + ", gender=" + gender + ", age=" + age + ", p_contact="
				+ p_contact + ", seat_no=" + seat_no + ", passport_no=" + passport_no + ", meal=" + meal
				+ ", no_of_seats=" + no_of_seats + "]";
	}
}
